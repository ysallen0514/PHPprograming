<?php
$host = getenv("IP");
$db = 'opendata';
$user = getenv('C9_USER');
$passwd = 'root';
$driver = 'mysql';
$charset = 'utf8';

$dsn = "{$driver}:host={$host};dbname={$db};charset={$charset}";
$opt = [PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_BOTH];