<?php
include 'PDO.dsn.php';
$pdo = new pdo($dsn, $user, $passwd, $opt);


if (!isset($_GET['editid'])) header('Location:main.php');
$editid = $_GET['editid'];

$pdo = new pdo($dsn, $user, $passwd, $opt);
$sql = "select * from travel where No = {$editid}";
$stmt = $pdo->prepare($sql);
$stmt->execute();
$editObj = $stmt->fetchObject()

?>
<head>
    <title>Introduction</title>
    <link href="css/main.css" rel="stylesheet">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <script src="jquery.mobile-1.3.2/jquery-1.9.1.min.js"></script>
    <script src="https://maps.googleapis.com/maps/api/js?v=3.exp&key=AIzaSyCRc91HOlBLyT4S414xtwKMczCGnnONabo"></script>
</head>
<body>
<nav class="navbar navbar-default navbar-inverse navbar-fixed-top">

    <div class="container-fluid">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="section-inner">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="tab"
                        data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="main.php">Home</a>
            </div>
        </div>
        <!-- Collect the nav links, forms, and other content for toggling -->
        <form class="navbar-form navbar-right" id="form1" name="form1" action="insert.php" method="post">
            <div class="col-lg-20">
                <div class="input-group">
                    <input class="form-control" type="text" id="addr" name="addr" placeholder="地點">
                    <span class="input-group-btn">
                                <input type="submit" class="btn btn-default" id="click" name="button" value="搜尋">
                            </span>
                </div><!-- /input-group -->
            </div><!-- /.col-lg-6 -->
        </form>
    </div>
    <!-- /.container-fluid -->
</nav>


<form class="smart-green">
    <h1><?php echo $editObj->name; ?></h1>

    <div>
        <label>
            <dir><img src="<?php echo $editObj->photo; ?>" class="img-responsive" alt="Responsive image"></dir>
            <dir>介紹 :</dir>
            <dir><?php echo $editObj->intro; ?></dir>

        </label>
    </div>

    <h2>
        <label>
            <dir>電話 : <?php echo $editObj->tel; ?></dir>
        </label>
        <label>
            <dir>地址 : <?php echo $editObj->addr; ?></dir>
        </label>
        <div id="googleMap" style="width: 98%; height: 300px;"></div>
    </h2>
</form>

<script>
    var centerpoint = new google.maps.LatLng(<?php echo $editObj->coordinate;?>)
    var mapProp = {
        center: centerpoint,
        zoom: 16,
        mapTypeId: google.maps.MapTypeId.ROADMAP
    };
    var map = new google.maps.Map(
        $("#googleMap")[0],
        mapProp);
    var marker = new google.maps.Marker({
        position: centerpoint,
        animation: google.maps.Animation.BOUNCE
    });

    marker.setMap(map);
</script>

<div class="footer">
    <div class="section-inner">
        <p>Based on bootstrap and PAIO-CO-KR-carousel-3d</p>
    </div>
</div>

</body>