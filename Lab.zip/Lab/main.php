<?php
include 'PDO.dsn.php';
$pdo = new pdo($dsn, $user, $passwd, $opt);

?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Home</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/main.css" rel="stylesheet">
    <link rel="stylesheet" href="./dist/styles/jquery.carousel-3d.default.css">
    <script src="./bower_components/jquery/jquery.js"></script>
    <script src="./src/jquery.resize.js"></script>
    <script src="./bower_components/waitForImages/dist/jquery.waitforimages.js"></script>
    <script src="./bower_components/modernizr/modernizr.js"></script>
    <script src="./dist/jquery.carousel-3d.js"></script>
</head>
<body>

<h1>農村旅遊景點</h1>

<nav class="navbar navbar-default navbar-fixed-top navbar-inverse">

    <div class="container-fluid">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="section-inner">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="tab"
                        data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="main.php">Home</a>
            </div>
        </div>


        <form class="navbar-form navbar-right" id="form1" name="form1" action="insert.php" method="post">
            <div class="col-lg-20">
                <div class="input-group">
                    <input class="form-control" type="text" id="addr" name="addr" placeholder="地點">
                    <span class="input-group-btn">
                                <input type="submit" class="btn btn-default" id="button" name="button" value="搜尋">
                            </span>
                </div><!-- /input-group -->
            </div><!-- /.col-lg-6 -->
        </form>


        <!-- /.navbar-collapse -->
    </div>
    <!-- /.container-fluid -->
</nav>

<div class="wrapper">
    <div data-carousel-3d>
        <?php
        $rand1 = rand(1, 301);
        $sql1 = "select * from travel WHERE id = '$rand1'";
        $stmt1 = $pdo->prepare($sql1);
        $stmt1->execute();
        $row1 = $stmt1->fetchObject();
        ?>
        <div>
            <a href='receive.php?editid=<?php echo $row1->No; ?>'><img src='<?php echo $row1->photo; ?>'
                                                                       class="img-responsive"
                                                                       alt="Responsive image"/></a>
            <div>
                <h1 class="alert alert-warning" role="alert"><?php echo $row1->name; ?></h1>
            </div>
        </div>


        <?php
        $rand2 = rand(1, 301);
        $sql2 = "select * from travel WHERE id = '$rand2'";
        $stmt2 = $pdo->prepare($sql2);
        $stmt2->execute();
        $row2 = $stmt2->fetchObject();
        ?>
        <div>
            <a href='receive.php?editid=<?php echo $row1->No; ?>'><img src='<?php echo $row2->photo; ?>'
                                                                       class="img-responsive"
                                                                       alt="Responsive image"/></a>
            <div>
                <h1 class="alert alert-warning" role="alert"><?php echo $row2->name; ?></h1>
            </div>
        </div>
        <?php
        $rand3 = rand(1, 301);
        $sql3 = "select * from travel WHERE id = '$rand3'";
        $stmt3 = $pdo->prepare($sql3);
        $stmt3->execute();
        $row3 = $stmt3->fetchObject();
        ?>
        <div>
            <a href='receive.php?editid=<?php echo $row1->No; ?>'><img src='<?php echo $row3->photo; ?>'
                                                                       class="img-responsive"
                                                                       alt="Responsive image"/></a>
            <div>
                <h1 class="alert alert-warning" role="alert"><?php echo $row3->name; ?></h1>
            </div>
        </div>
        <?php
        $rand4 = rand(1, 301);
        $sql4 = "select * from travel WHERE id = '$rand4'";
        $stmt4 = $pdo->prepare($sql4);
        $stmt4->execute();
        $row4 = $stmt4->fetchObject();
        ?>
        <div>
            <a href='receive.php?editid=<?php echo $row1->No; ?>'><img src='<?php echo $row4->photo; ?>'
                                                                       class="img-responsive"
                                                                       alt="Responsive image"/></a>
            <div>
                <h1 class="alert alert-warning" role="alert"><?php echo $row4->name; ?></h1>
            </div>
        </div>
        <?php
        $rand5 = rand(1, 301);
        $sql5 = "select * from travel WHERE id = '$rand5'";
        $stmt5 = $pdo->prepare($sql5);
        $stmt5->execute();
        $row5 = $stmt5->fetchObject();
        ?>
        <div>
            <a href='receive.php?editid=<?php echo $row1->No; ?>'><img src='<?php echo $row5->photo; ?>'
                                                                       class="img-responsive"
                                                                       alt="Responsive image"/></a>
            <div>
                <h1 class="alert alert-warning" role="alert"><?php echo $row5->name; ?></h1>
            </div>
        </div>
        <?php
        $rand6 = rand(1, 301);
        $sql6 = "select * from travel WHERE id = '$rand6'";
        $stmt6 = $pdo->prepare($sql6);
        $stmt6->execute();
        $row6 = $stmt6->fetchObject();
        ?>
        <div>
            <a href='receive.php?editid=<?php echo $row1->No; ?>'><img src='<?php echo $row6->photo; ?>'
                                                                       class="img-responsive"
                                                                       alt="Responsive image"/></a>
            <div>
                <h1 class="alert alert-warning" role="alert"><?php echo $row6->name; ?></h1>
            </div>
        </div>
    </div>
</div>

<div class="footer">
    <div class="section-inner">
        <p>Based on bootstrap and PAIO-CO-KR-carousel-3d</p>
    </div>
</div>

</body>
</html>