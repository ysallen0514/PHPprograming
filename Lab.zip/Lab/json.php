<?php
include 'PDO.dsn.php';
$pdo = new pdo($dsn, $user, $passwd, $opt);
$sql = "insert into travel(No,name,tel,intro,addr,coordinate,photo) VALUES (?,?,?,?,?,?,?)";

$json = file_get_contents("http://data.coa.gov.tw/Service/OpenData/ODwsv/ODwsvAttractions.aspx");

$root = json_decode($json);

foreach ($root as $row) {
    $No = $row->ID;
    $name = $row->Name;
    $tel = $row->Tel;
    $intro = $row->Introduction;
    $addr = $row->Address;
    $coordinate = $row->Coordinate;
    $photo = $row->Photo;
    $stmt = $pdo->prepare($sql)->execute([$No,$name,$tel,$intro,$addr,$coordinate,$photo]);
}

