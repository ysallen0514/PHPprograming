<head>
    <title></title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/main.css" rel="stylesheet">
</head>

<body>
<div class="navbar navbar-default navbar-inverse">

    <div class="container-fluid">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="section-inner">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="tab"
                        data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="main.php">Home</a>
            </div>
        </div>
        <!-- Collect the nav links, forms, and other content for toggling -->
        <form class="navbar-form navbar-right" id="form1" name="form1" action="insert.php" method="post">
            <div class="col-lg-20">
                <div class="input-group">
                    <input class="form-control" type="text" id="addr" name="addr" placeholder="地點">
                    <span class="input-group-btn">
                                <input type="submit" class="btn btn-default" id="click" name="button" value="搜尋">
                            </span>
                </div><!-- /input-group -->
            </div><!-- /.col-lg-6 -->
        </form>
    </div>
    <!-- /.container-fluid -->
</div>

<?php
include 'PDO.dsn.php';
session_start();

if (!isset($_POST['addr'])) die("");
$addr = $_POST['addr'];
$_SESSION['addr'] = $addr;
$pdo = new pdo($dsn, $user, $passwd, $opt);
$sql6 = "select * from travel where addr LIKE '%$addr%'";
$stmt6 = $pdo->prepare($sql6);
$stmt6->execute();

if ($addr != "") {
    echo "";
    echo "<table id='one-column-emphasis''>";
    echo "<colgroup>";
    echo "<col class='oce-first' />";
    echo "</colgroup>";
    echo "<thead>";
    echo "<tr>";
    echo "<th scope='col'>地點</th>";
    echo "<th scope='col'>地址</th>";
    echo "<th scope='col'>電話</th>";
    echo "</tr>";
    echo "</thead>";

    while ($row6 = $stmt6->fetchObject()) {
        echo "<tbody>";
        echo "<tr>";
        echo "<td><a href='receive.php?editid={$row6->No}'>$row6->name</a></td>";
        echo "<td>$row6->addr</td>";
        echo "<td>$row6->tel</td>";
        echo "</tr>";
        echo "</tbody>";
    }
    echo "</table>";
} else {
    echo "";
}
?>


<div class="footer">
    <div class="section-inner">
        <p>Based on bootstrap and PAIO-CO-KR-carousel-3d</p>
    </div>
</div>
</body>